#include <msp430.h> 

int test = 0;
int temp = 0, temproom = 0;
int ADCReading[3];
/*
 * main.c
 */
void lights(int c);
//Turns Tank Lights on
void cleaningneeded();
//turns light on when cleaning needed
void feeder();
//initiates fish food
void heater(int a);
//heats tank water
void pump(int b);
//starts pump
void getanalogvalues();
//turbidity sensor
void ConfigureAdc(void);
//configures the ADC



int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
    P2REN = 0;
    P2DIR = 0;
	P1DIR = (BIT0 | BIT1 | BIT2);
	P2DIR |= ( BIT0 | BIT1       );
    //P1OUT = 0;
    ConfigureAdc();

    getanalogvalues();
    temproom = temp;
    __delay_cycles(250);

    for(;;)
    {
        /*
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT2; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = 0; __delay_cycles(100000);//break
    */
        getanalogvalues();

        if(temp > temproom * 1.02 && temp < temproom * 1.04 )
        {}
            //if temp is higher than 1.04 * temproom, turn LED2 on
            //if temp is lower  than 1.02 * temproom, turn LED2 off
        else
        {
            if(temp > temproom * 1.04)
                {P2OUT |=  BIT0; __delay_cycles(200);}    // SSR on
            else
                {P2OUT &= ~BIT0; __delay_cycles(200);}    // SSR off
        }

    }

    //start turbitity
    /*int photocellPin = A1;    //connect cell to analog pin 0 with 10k pull down resistor to ground
    int ledPin = 13;  //Connect LED to run pin 13 in series with appropriate resistor

    void setup() {
      Serial.begin(9600);  //Begin serial connection between Arduino and PC
      pinMode (ledPin, OUTPUT);  //Set pin to outut
     pinMode (photocellPin, INPUT);

    }

    void loop() {
     Serial.print("Cell = ");
     Serial.println(analogRead(photocellPin));  //print analog read to serial monitor on PC

    float val = analogRead(photocellPin);  //create variable to take in analog reading from cell
    Serial.print("val ");
    Serial.println(val);
    digitalWrite(13, HIGH);
    float ardval = val*0.00488758553;  //arduino value units
    Serial.print("ardval ");
    Serial.println(ardval);
    float r1 = (50000/ardval)-10000; //R1 value when using Ohm's law
    Serial.print("r1 ");
    Serial.println(r1);
    float I = ardval/r1; //value of I which we are solving for
    float NTUval = I*70000;  //200 = units in NTU
    delay(1000);

    delay(1000);

    delay(1000);
    Serial.print("I ");
    Serial.println(I);
    delay(1000);
    Serial.print("NTUval ");
    Serial.println(NTUval);
    delay(1000);*/
    //end turbidity
	return 0;
}

/*void lights(int c)
    {
    int lighttimer = c;
    int count;
    while (count < lighttimer)
        {
        P#OUT = BIT#;
        }
    }
//Turns Tank Lights on
void feeder()
    {
    P#OUT = BIT#; __delay_cycles(1000000);
    }
//initiates fish food
void heater(int a)
    {
    int temp = a;
    while(a<10000)
        {
        P#OUT = BIT#;
        a++;
        }
    }
//heats tank water
void pump(int b)
    {
    int time = 0;
    while (time<b)
        {
        P#OUT = BIT#;
        time++;
        }
    }
//starts pump
 * */
void ConfigureAdc(void)
{
   ADC10CTL1 = INCH_3 | CONSEQ_1;             // A2 + A1 + A0, single sequence
   ADC10CTL0 = ADC10SHT_2 | MSC | ADC10ON;
   while (ADC10CTL1 & BUSY);
   ADC10DTC1 = 0x03;                      // 1 conversion
   ADC10AE0 |= (BIT3 | BIT4);              // ADC10 option select
}
void cleaningneeded()
    {
    P1OUT = BIT2; __delay_cycles(200000);
    P1OUT = 0; __delay_cycles(200000);
    }
//turns light on when cleaning needed
void getanalogvalues()
{
 int i = 0;
 test = 0;            // set all analog values to zero
 for(i=1; i<=5 ; i++)                          // read all three analog values 5 times each and average
     {
         ADC10CTL0 &= ~ENC;
         while (ADC10CTL1 & BUSY);                         //Wait while ADC is busy
         ADC10SA = (unsigned)&ADCReading[0];           //RAM Address of ADC Data, must be reset every conversion
         ADC10CTL0 |= (ENC | ADC10SC);                     //Start ADC Conversion
         while (ADC10CTL1 & BUSY);
         test += ADCReading[0];
         temp += ADCReading[1];                     // sum  all 5 reading for the three variables
     }
     test = test/5;     // Average the 5 reading for the three variables
     if (test < 350) //975 to 999
         {
             cleaningneeded(); __delay_cycles(5000);
         }
     else
         {
         P1OUT = BIT1; __delay_cycles(5000);
         }
}
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    __bic_SR_register_on_exit(CPUOFF);
}
