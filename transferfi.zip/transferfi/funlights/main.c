#include <msp430.h> 
/*
 * main.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    P2REN = 0;
    P2DIR = 0;
    P1DIR = (BIT0 | BIT1 | BIT2);
    P2DIR |= ( BIT0 | BIT1       );

    for(;;)
    {

        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT2; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = 0; __delay_cycles(100000);//break

        }
    return 0;
}
