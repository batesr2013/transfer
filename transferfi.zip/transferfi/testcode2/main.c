#include <msp430.h> 

int test = 0;
int temp = 0, temproom = 0;
int ADCReading[3];
/*
 * main.c
 */
void lights(int c);
//Turns Tank Lights on by passing it a time to stay on
void cleaningneeded();
//turns light on when cleaning needed for tank
void feeder();
//initiates fish food for a designated period of time then stops the motor
void heater();
//heats tank water for a short period of time
void pump();
//starts pump for a set period of time
void getanalogvalues();
//turbidity and temp sensor data retrieval
void ConfigureAdc(void);
//configures the ADC



int main(void) {
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    P2REN = 0;
    P2DIR = 0;
    P1DIR = (BIT0 | BIT1 | BIT2);
    P2DIR |= ( BIT0 | BIT1       );

    ConfigureAdc();

    getanalogvalues();
    temproom = temp;
    __delay_cycles(250);

    for(;;)
    {
        /*
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT2; __delay_cycles(200000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT0; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = BIT1; __delay_cycles(10000);
        P1OUT = BIT2; __delay_cycles(10000);
        P1OUT = 0; __delay_cycles(100000);//break
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = BIT0; __delay_cycles(5000);
        P1OUT = BIT1; __delay_cycles(5000);
        P1OUT = BIT2; __delay_cycles(5000);
        P1OUT = 0; __delay_cycles(100000);//break
    */
        getanalogvalues();

        if(temp > temproom * 1.02 && temp < temproom * 1.04 )
        {}
        else
        {
            if(temp > temproom * 1.04)
                {P2OUT |=  BIT0; __delay_cycles(200);}    // SSR on
            else
                {P2OUT &= ~BIT0; __delay_cycles(200);}    // SSR off
        }

    }
    return 0;
}

void lights(int c)
    {
    int lighttimer = c;
    int count;
    while (count < lighttimer)
        {
        P#OUT |= BIT#;
        count++;
        }
    }
//Turns Tank Lights on
void feeder()
    {
    P#OUT = BIT#; __delay_cycles(1000000);
    P#OUT = 0;
    }
//initiates fish food
void heater()
    {
    int a = 0;
    while(a<10000)
        {
        P#OUT = BIT#;
        a++;
        }
    P#OUT = 0;
    }
//heats tank water
void pump()
    {
    int time = 0;
    while (time<50000)
        {
        P#OUT = BIT#;
        time++;
        }
        P#OUT = 0;
    }
//starts pump
void ConfigureAdc(void)
{
   ADC10CTL1 = INCH_3 | CONSEQ_1;             // A2 + A1 + A0, single sequence
   ADC10CTL0 = ADC10SHT_2 | MSC | ADC10ON;
   while (ADC10CTL1 & BUSY);
   ADC10DTC1 = 0x03;                      // 1 conversion
   ADC10AE0 |= (BIT3 | BIT4);              // ADC10 option select
}
void cleaningneeded()
    {
    P1OUT = BIT2; __delay_cycles(200000);
    P1OUT = 0; __delay_cycles(200000);
    pump();
    }
//turns light on when cleaning needed
void getanalogvalues()
{
 int i = 0;
 test = 0;            // set all analog values to zero
 for(i=1; i<=5 ; i++)                          // read all three analog values 5 times each and average
     {
         ADC10CTL0 &= ~ENC;
         while (ADC10CTL1 & BUSY);                         //Wait while ADC is busy
         ADC10SA = (unsigned)&ADCReading[0];           //RAM Address of ADC Data, must be reset every conversion
         ADC10CTL0 |= (ENC | ADC10SC);                     //Start ADC Conversion
         while (ADC10CTL1 & BUSY);
         test += ADCReading[0];
         temp += ADCReading[1];                     // sum  all 5 reading for the three variables
     }
     test = test/5;     // Average the 5 reading for the three variables
     if (test < 350) //975 to 999
         {
             cleaningneeded(); __delay_cycles(5000);
         }
     else
         {
         P1OUT = BIT1; __delay_cycles(5000);
         }
}
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    __bic_SR_register_on_exit(CPUOFF);
}










for(i=0;i<2;)
if (int a = k)
{
    while(int a = k)
    {}
if (int a = k)
{
    while(int a = k)
    {}
if (int a = k)
{
    while(int a = k)
    {}
if (int a = k)
{
//MAIN PROGRAM
}
}
else
{
i = 2;
}
}
else
{
i = 2;
}
}
else
{
i = 2;
}




