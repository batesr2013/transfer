#include <msp430.h> 

/*
 * main.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	int R5_SW = 0;
	int R6LED = 0;
	int temp = 0;
	P1OUT = 0b00000000;
	P1DIR = 0b11111111;
	P2DIR = 0b00000000;
	while(1)
	{
	    R5_SW = P2IN;
	    if(R5_SW & BIT0)
	    {
	        R6LED = R5_SW &(BIT3|BIT4|BIT5);
	        P1OUT = R6LED;
	    }
	    else
	    {
	        if(R5_SW & BIT1)
	        {
	            R6LED = (R6LED>>1)|(R6LED<<7);
	        }
	        else
	        {
	            R6LED = (R6LED<<1)|(R6LED>>7);
	        }
	        R6LED &= 0xFF;
	        P1OUT = R6LED;
	        if(R5_SW & BIT2)
	        {
	            __delay_cycles(40000);
	        }
	        else
	        {
	            __delay_cycles(100000);
	        }
	    }
	}
	return 0;
}
